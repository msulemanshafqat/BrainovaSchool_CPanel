@extends('backend.master')

@section('title')
    {{ @$data['title'] }}
@endsection

@section('content')
    <input type="hidden" id="url" value="{{ url('/') }}">
    
    <div class="page-content">
        {{-- bradecrumb Area S t a r t --}}
        <div class="page-header">
            <div class="row">
                <div class="col-sm-6">
                    <h4 class="bradecrumb-title mb-1">{{ $data['title'] }}</h4>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ ___('common.home') }}</a></li>
                            <li class="breadcrumb-item" aria-current="page"><a
                                    href="{{ route('homework.index') }}">{{ $data['title'] }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ ___('common.add_new') }}</li>
                        </ol>
                </div>
            </div>
        </div>
        {{-- bradecrumb Area E n d --}}
        
        <div class="card ot-card">
            <div class="card-body">
                <form action="{{ route('homework.store') }}" enctype="multipart/form-data" method="post" id="markRegister">
                    @csrf
                    <div class="row mb-3">
                        <div class="col-lg-12">
                            <div class="row">

                                <div class="col-md-4 mb-3">
                                    <label for="validationServer04" class="form-label">{{ ___('student_info.class') }} <span class="fillable">*</span></label>
                                    <select id="getSections" class="nice-select niceSelect bordered_style wide class @error('class') is-invalid @enderror" name="class" id="validationServer04" aria-describedby="validationServer04Feedback">
                                        <option value="">{{ ___('student_info.select_class') }}</option>
                                        @foreach ($data['classes'] as $item)
                                            <option {{ old('class') == $item->id ? 'selected' : '' }} value="{{ $item->class->id }}">{{ $item->class->name }}</option>
                                        @endforeach
                                    </select>
                                    @error('class')
                                        <div id="validationServer04Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label for="validationServer04" class="form-label">{{ ___('student_info.section') }} <span class="fillable">*</span></label>
                                    <select id="getSubjects" class="nice-select niceSelect sections bordered_style wide section @error('section') is-invalid @enderror" name="section" id="validationServer04" aria-describedby="validationServer04Feedback">
                                        <option value="">{{ ___('student_info.select_section') }}</option>
                                    </select>
                                    @error('section')
                                        <div id="validationServer04Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label for="validationServer04" class="form-label">{{ ___('academic.subject') }} <span class="fillable">*</span></label>
                                    <select id="subject" class="nice-select niceSelect subjects bordered_style wide @error('subject') is-invalid @enderror" name="subject" id="validationServer04" aria-describedby="validationServer04Feedback">
                                        <option value="">{{ ___('examination.select_subject') }}</option>
                                    </select>
                                    @error('subject')
                                        <div id="validationServer04Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label class="form-label">{{ ___('common.Task Category') }} <span class="fillable">*</span></label>
                                    <select id="task_type" class="nice-select niceSelect bordered_style wide @error('task_type') is-invalid @enderror" name="task_type">
                                        <option value="homework">Standard Homework</option>
                                        <option value="project">Project</option>
                                        <option value="activity">Activity</option>
                                        <option value="game">Educational Game</option>
                                        <option value="assignment">Assignment</option>
                                        <option value="quiz">Quiz</option>
                                    </select>
                                    @error('task_type')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="exampleDataList" class="form-label ">{{ ___('account.date') }} <span class="fillable">*</span></label>
                                    <input class="form-control ot-input @error('date') is-invalid @enderror" name="date" type="date" value="{{ old('date') }}" id="exampleDataList" placeholder="{{ ___('common.enter_date') }}">
                                    @error('date')
                                        <div id="validationServer06Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label for="exampleDataList" class="form-label ">{{ ___('common.submission_date') }} <span class="fillable"></span></label>
                                    <input class="form-control ot-input @error('submission_date') is-invalid @enderror" name="submission_date" type="date" value="{{ old('submission_date') }}" id="exampleDataList" placeholder="{{ ___('common.enter_submission_date') }}">
                                    @error('submission_date')
                                        <div id="validationServer06Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label for="exampleDataList" class="form-label ">{{ ___('examination.marks') }}</label>
                                    <input class="form-control ot-input @error('marks') is-invalid @enderror" name="marks" id="total-marks" value="{{ old('marks') }}" placeholder="{{ ___('examination.marks') }}">
                                    @error('marks')
                                        <div id="validationServer04Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

<div class="col-md-4" id="standard_upload_div">
    <label class="form-label ">{{ ___('common.document') }}</label>
    <div class="ot_fileUploader left-side mb-3">
        <input class="form-control" type="text" placeholder="{{ ___('common.document') }}" readonly="" id="placeholder">
        <button class="primary-btn-small-input" type="button">
            <label class="btn btn-lg ot-btn-primary" for="fileBrouse">{{ ___('common.browse') }}</label>
            <input type="file" class="d-none form-control" name="document" id="fileBrouse" accept="image/*,.pdf,.doc,.docx">
        </button>
    </div>
</div>

<div class="col-md-4 mb-3" id="question_group_div">
    <label class="form-label">{{ ___('examination.question_group') }} <span class="fillable">*</span></label>
    <select id="question_group" class="nice-select niceSelect bordered_style wide" name="question_group">
        <option value="">{{ ___('online-examination.Select question group') }}</option>
        @foreach ($data['question_groups'] as $item)
            <option value="{{ $item->id }}">{{ $item->name }}</option>
        @endforeach
    </select>
</div>

                                <div class="col-md-4 mb-3">
                                    <label for="validationServer04" class="form-label">{{ ___('common.status') }} <span class="fillable">*</span></label>
                                    <select class="nice-select niceSelect bordered_style wide @error('status') is-invalid @enderror" name="status" id="validationServer04" aria-describedby="validationServer04Feedback">
                                        <option value="{{ App\Enums\Status::ACTIVE }}">{{ ___('common.active') }}</option>
                                        <option value="{{ App\Enums\Status::INACTIVE }}">{{ ___('common.inactive') }}</option>
                                    </select>
                                    @error('status')
                                        <div id="validationServer04Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

<div class="col-md-12 mb-4 d-none" id="quiz_upload_div">
    <div class="card border-dashed" style="background-color: #f8fafc; border: 2px dashed #cbd5e1;">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div>
                    <h5 class="mb-1">🚀 Bulk Question Upload (CSV Only)</h5>
                    <p class="text-muted small mb-0">Upload your quiz CSV or download the template below.</p>
                </div>
                
                
                
             
              <a href="{{ asset('Quiz_Template.csv') }}" class="btn btn-sm btn-outline-primary" download="Quiz_Template.csv">
    <i class="fa-solid fa-download"></i> Download CSV Template
</a>
                
            
                   
                </a>
            </div>
            <input type="file" name="bulk_questions_file" class="form-control" accept=".csv">
        </div>
    </div>
</div>
                                <div class="col-md-12 mb-3 d-none" id="question_list_div">
                                    <h5>{{ ___('online-examination.Question list') }}</h5>
                                    <div class="table-responsive">
                                        <input type="hidden" id="page" value="create">
                                        <table class="table table-bordered role-table" id="types_table">
                                            <thead class="thead">
                                                <tr>
                                                    <th class="purchase mr-4">{{ ___('common.Select') }} </th>
                                                    <th class="purchase">{{ ___('online-examination.Question') }}</th>
                                                    <th class="purchase">{{ ___('online-examination.Mark') }}</th>
                                                    <th class="purchase">{{ ___('online-examination.Type') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody class="tbody"></tbody>
                                        </table>
                                    </div>
                                    @if ($errors->has('questions_ids'))
                                        <span class="text-danger">{{ ___('online-examination.At least select one.') }}</span>
                                    @endif
                                </div>
                                
                                <div class="col-md-12 mb-3">
                                    <label for="exampleDataList" class="form-label ">{{ ___('account.description') }}</label>
                                    <textarea class="form-control ot-textarea @error('description') is-invalid @enderror" name="description" placeholder="{{ ___('account.enter_description') }}">{{ old('description') }}</textarea>
                                    @error('description')
                                        <div id="validationServer04Feedback" class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-12 mt-24">
                                    <div class="text-end">
                                        <button class="btn btn-lg ot-btn-primary"><span><i class="fa-solid fa-save"></i> </span>{{ ___('common.submit') }}</button>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </form> 
            </div>
        </div>
    </div>
@endsection


@push('script')
    <script>
        $(document).ready(function() {
            
            // 1. Task Category Logic (Browse Button & Bulk Upload visibility)
            $('#task_type').on('change', function() {
                var selectedTask = $(this).val();

                if (selectedTask === 'quiz') {
                    $('#quiz_upload_div').removeClass('d-none');
                    $('#fileBrouse').attr('accept', '.csv'); // Only CSV for Quizzes
                } else {
                    $('#quiz_upload_div').addClass('d-none');
                    $('#fileBrouse').attr('accept', 'image/*,.pdf,.doc,.docx'); // All types for others
                }
            });

            // 2. Question Group Logic (Loads the list)
            $('#question_group').on('change', function() {
                var id = $(this).val();
                if (id) {
                    getAllQuestions(id); // Calls the AJAX function below
                } else {
                    $("#question_list_div").addClass('d-none');
                }
            });

            // 3. Total Marks Calculation Logic (KEEP THIS)
            function updateTotalMarks() {
                let total = 0;
                // Sums up the marks from all checked questions
                $('input[name="questions_ids[]"]:checked').each(function() {
                    total += parseFloat($(this).data('mark')) || 0;
                });
                $('#total-marks').val(total);
            }

            // Trigger calculation whenever a checkbox is clicked
            $(document).on('change', 'input[name="questions_ids[]"]', function() {
                updateTotalMarks();
            });

            // Run once on page load (important if there are validation errors)
            updateTotalMarks();
        });

        // 4. AJAX Function (Outside the ready block)
        function getAllQuestions(id) {
            var url = $('#url').val(); 
            $.ajax({
                type: "GET",
                dataType: 'html',
                data: { id: id },
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                url: url + '/homework/get-all-questions', 
                success: function(data) {
                    // Fill table and show the section ONLY after success
                    $("#types_table tbody").empty().append(data);
                    $("#question_list_div").removeClass('d-none');
                },
                error: function(err) {
                    console.error("AJAX Error:", err);
                    $("#question_list_div").addClass('d-none');
                }
            });
        }
    </script>
@endpush
